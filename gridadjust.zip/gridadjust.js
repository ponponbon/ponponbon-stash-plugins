// gridadjust.js
// Always enforce default sorting and zoom on Scenes page
(function () {
    const applyDefaults = () => {
      const { pathname } = window.location;
      if (!pathname.startsWith("/scenes")) return;
  
      const url = new URL(window.location.href);
      const sp = url.searchParams;
  
      // force parameters regardless of settings
      sp.set("sortby", "updated_at");
      sp.set("sortdir", "desc");
      sp.set("z", "3");
  
      window.location.replace(url.pathname + "?" + sp.toString());
    };
  
    applyDefaults();
  
    // re-apply if navigation occurs within the SPA
    const hook = () => setTimeout(applyDefaults, 0);
    const push = history.pushState;
    const replace = history.replaceState;
    history.pushState = function () { push.apply(this, arguments); hook(); };
    history.replaceState = function () { replace.apply(this, arguments); hook(); };
    window.addEventListener("popstate", hook);
  })();
  